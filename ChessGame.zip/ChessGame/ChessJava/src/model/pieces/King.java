package model.pieces;

import model.board.Board;
import model.board.Position;

import java.util.ArrayList;
import java.util.List;

public class King extends Piece {
    public King(Board board, boolean white) { super(board, white); }

    @Override public String getSymbol() { return "K"; }
    @Override public String getUnicode() { return white ? "♔" : "♚"; }

    @Override
    public List<Position> getMoves() {
        List<Position> res = new ArrayList<>();
        int[] d = {-1, 0, 1};
        for (int dr : d) for (int dc : d) {
            if (dr == 0 && dc == 0) continue;
            Position p = position.add(dr, dc);
            if (canCaptureOrEmpty(p)) res.add(p);
        }
        return res;
    }
}
