package model.pieces;

import model.board.Board;
import model.board.Position;

import java.util.ArrayList;
import java.util.List;

public class Knight extends Piece {
    public Knight(Board board, boolean white) { super(board, white); }

    @Override public String getSymbol() { return "N"; }
    @Override public String getUnicode() { return white ? "♘" : "♞"; }

    @Override
    public List<Position> getMoves() {
        List<Position> res = new ArrayList<>();
        int[][] d = {{2,1},{2,-1},{-2,1},{-2,-1},{1,2},{1,-2},{-1,2},{-1,-2}};
        for (int[] v : d) {
            Position p = position.add(v[0], v[1]);
            if (canCaptureOrEmpty(p)) res.add(p);
        }
        return res;
    }
}
