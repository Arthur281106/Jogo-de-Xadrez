package model.pieces;

import controller.Game;
import model.board.Position;

import java.util.*;

public class SimpleAI {
    private final Game game;
    private final int difficulty; // 0 = fácil, 1 = médio, 2 = difícil
    private final Random rng = new Random();

    public SimpleAI(Game game, int difficulty) {
        this.game = game;
        this.difficulty = difficulty;
    }

    public void makeMove() {
        if (game.isGameOver()) return;

        boolean side = game.isWhiteTurn();
        List<MoveCandidate> candidates = new ArrayList<>();

        for (Piece p : game.getBoard().getAllPieces(side)) {
            for (Position mv : game.getLegalMoves(p)) {
                Piece target = game.getBoard().getPieceAt(mv);
                int value = (target == null) ? 0 : getPieceValue(target);
                candidates.add(new MoveCandidate(p, mv, value));
            }
        }

        if (candidates.isEmpty()) return;

        MoveCandidate chosen;

        switch (difficulty) {
            case 0: // fácil
                chosen = candidates.get(rng.nextInt(candidates.size()));
                break;
            case 1: // médio: prioriza capturas
                List<MoveCandidate> captures = candidates.stream()
                        .filter(c -> c.value > 0)
                        .toList();
                chosen = captures.isEmpty()
                        ? candidates.get(rng.nextInt(candidates.size()))
                        : captures.get(rng.nextInt(captures.size()));
                break;
            case 2: // difícil: escolhe melhor valor
                candidates.sort((a, b) -> Integer.compare(b.value, a.value));
                chosen = candidates.get(0);
                break;
            default:
                chosen = candidates.get(rng.nextInt(candidates.size()));
        }

        game.select(chosen.piece.getPosition());
        game.move(chosen.dest);
    }

    private int getPieceValue(Piece p) {
        return switch (p.getSymbol()) {
            case "P" -> 1;
            case "N", "B" -> 3;
            case "R" -> 5;
            case "Q" -> 9;
            case "K" -> 100;
            default -> 0;
        };
    }

    private static class MoveCandidate {
        final Piece piece;
        final Position dest;
        final int value;

        MoveCandidate(Piece piece, Position dest, int value) {
            this.piece = piece;
            this.dest = dest;
            this.value = value;
        }
    }
}
