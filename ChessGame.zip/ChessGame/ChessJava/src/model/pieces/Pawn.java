package model.pieces;

import model.board.Board;
import model.board.Position;

import java.util.ArrayList;
import java.util.List;

public class Pawn extends Piece {
    public Pawn(Board board, boolean white) { super(board, white); }

    @Override public String getSymbol() { return "P"; }
    @Override public String getUnicode() { return white ? "♙" : "♟"; }

    @Override
    public List<Position> getMoves() {
        List<Position> res = new ArrayList<>();
        int dir = white ? -1 : 1;
        Position one = position.add(dir, 0);
        if (one.isValid() && board.getPieceAt(one) == null) {
            res.add(one);
            // duplo passo inicial
            int startRow = white ? 6 : 1;
            Position two = position.add(2 * dir, 0);
            if (position.getRow() == startRow && board.getPieceAt(two) == null) {
                res.add(two);
            }
        }
        // capturas diagonais
        Position dl = position.add(dir, -1);
        Position dr = position.add(dir, 1);
        if (canCaptureOnly(dl)) res.add(dl);
        if (canCaptureOnly(dr)) res.add(dr);
        return res;
    }

    @Override
    public List<Position> getAttacks() {
        List<Position> res = new ArrayList<>();
        int dir = white ? -1 : 1;
        Position dl = position.add(dir, -1);
        Position dr = position.add(dir, 1);
        if (dl.isValid()) res.add(dl);
        if (dr.isValid()) res.add(dr);
        return res;
    }
}
