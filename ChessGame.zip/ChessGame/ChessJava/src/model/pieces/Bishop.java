package model.pieces;

import model.board.Board;
import model.board.Position;

import java.util.ArrayList;
import java.util.List;

public class Bishop extends Piece {
    public Bishop(Board board, boolean white) { super(board, white); }

    @Override public String getSymbol() { return "B"; }
    @Override public String getUnicode() { return white ? "♗" : "♝"; }

    @Override
    public List<Position> getMoves() {
        List<Position> res = new ArrayList<>();
        ray(res, 1,1); ray(res, 1,-1); ray(res,-1,1); ray(res,-1,-1);
        return res;
    }
}
