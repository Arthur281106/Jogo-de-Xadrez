package model.pieces;

import model.board.Board;
import model.board.Position;

import java.util.ArrayList;
import java.util.List;

public abstract class Piece {
    protected final Board board;
    protected final boolean white;
    protected Position position;

    protected Piece(Board board, boolean white) {
        this.board = board;
        this.white = white;
    }

    public boolean isWhite() { return white; }
    public Position getPosition() { return position; }
    public void setPosition(Position p) { this.position = p; }

    public abstract String getSymbol();
    public abstract String getUnicode();

    // movimentos que a peça tentaria executar (sem checar xeque no próprio rei)
    public abstract List<Position> getMoves();

    // casas que a peça ataca (peões atacam diferente de mover)
    public List<Position> getAttacks() { return new ArrayList<>(getMoves()); }

    protected boolean canCaptureOrEmpty(Position p) {
        if (!p.isValid()) return false;
        var target = board.getPieceAt(p);
        return target == null || target.isWhite() != this.white;
    }

    protected boolean canCaptureOnly(Position p) {
        if (!p.isValid()) return false;
        var target = board.getPieceAt(p);
        return target != null && target.isWhite() != this.white;
    }

    protected void ray(List<Position> acc, int dr, int dc) {
        Position cur = position.add(dr, dc);
        while (cur.isValid()) {
            var target = board.getPieceAt(cur);
            if (target == null) {
                acc.add(cur);
            } else {
                if (target.isWhite() != this.white) acc.add(cur);
                break;
            }
            cur = cur.add(dr, dc);
        }
    }
}
