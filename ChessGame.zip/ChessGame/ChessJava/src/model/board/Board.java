package model.board;

import model.pieces.*;

import java.util.ArrayList;
import java.util.List;

public class Board {
    private final Piece[][] grid = new Piece[8][8];

    public Piece getPieceAt(Position p) {
        if (p == null || !p.isValid()) return null;
        return grid[p.getRow()][p.getColumn()];
    }

    public void placePiece(Piece piece, Position p) {
        if (piece == null || p == null || !p.isValid()) return;
        grid[p.getRow()][p.getColumn()] = piece;
        piece.setPosition(p);
    }

    public Piece removePiece(Position p) {
        if (p == null || !p.isValid()) return null;
        Piece tmp = grid[p.getRow()][p.getColumn()];
        grid[p.getRow()][p.getColumn()] = null;
        return tmp;
    }

    public Piece movePiece(Position from, Position to) {
        if (from == null || to == null) return null;
        Piece moving = getPieceAt(from);
        Piece captured = getPieceAt(to);
        removePiece(from);
        if (moving != null) placePiece(moving, to);
        return captured;
    }

    public boolean isEmpty(Position p) { return getPieceAt(p) == null; }

    public List<Piece> getAllPieces(boolean white) {
        List<Piece> res = new ArrayList<>();
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            Piece pc = grid[r][c];
            if (pc != null && pc.isWhite() == white) res.add(pc);
        }
        return res;
    }

    public Position findKing(boolean white) {
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            Piece pc = grid[r][c];
            if (pc instanceof King && pc.isWhite() == white) return new Position(r, c);
        }
        return null;
    }

    public boolean isUnderAttack(Position pos, boolean byWhite) {
        // usa ataques (não movimentos) — especialmente importante para peões
        for (Piece p : getAllPieces(byWhite)) {
            for (Position a : p.getAttacks()) {
                if (a.equals(pos)) return true;
            }
        }
        return false;
    }

    public void setupInitial() {
        // limpa
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) grid[r][c] = null;

        // peões
        for (int c = 0; c < 8; c++) {
            placePiece(new Pawn(this, true), new Position(6, c));
            placePiece(new Pawn(this, false), new Position(1, c));
        }
        // brancas (fundo linha 7)
        placePiece(new Rook(this, true),   new Position(7, 0));
        placePiece(new Knight(this, true), new Position(7, 1));
        placePiece(new Bishop(this, true), new Position(7, 2));
        placePiece(new Queen(this, true),  new Position(7, 3));
        placePiece(new King(this, true),   new Position(7, 4));
        placePiece(new Bishop(this, true), new Position(7, 5));
        placePiece(new Knight(this, true), new Position(7, 6));
        placePiece(new Rook(this, true),   new Position(7, 7));

        // pretas (fundo linha 0)
        placePiece(new Rook(this, false),   new Position(0, 0));
        placePiece(new Knight(this, false), new Position(0, 1));
        placePiece(new Bishop(this, false), new Position(0, 2));
        placePiece(new Queen(this, false),  new Position(0, 3));
        placePiece(new King(this, false),   new Position(0, 4));
        placePiece(new Bishop(this, false), new Position(0, 5));
        placePiece(new Knight(this, false), new Position(0, 6));
        placePiece(new Rook(this, false),   new Position(0, 7));
    }
}
