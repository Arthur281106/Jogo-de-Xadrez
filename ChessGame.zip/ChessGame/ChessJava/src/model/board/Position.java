package model.board;

import java.util.Objects;

public class Position {
    private final int row;
    private final int column;

    public Position(int row, int column) {
        this.row = row;
        this.column = column;
    }

    public int getRow() { return row; }
    public int getColumn() { return column; }

    public boolean isValid() {
        return row >= 0 && row < 8 && column >= 0 && column < 8;
    }

    public Position add(int dr, int dc) {
        return new Position(row + dr, column + dc);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Position)) return false;
        Position p = (Position) o;
        return row == p.row && column == p.column;
    }

    @Override
    public int hashCode() { return Objects.hash(row, column); }

    @Override
    public String toString() { return "(" + row + "," + column + ")"; }
}
