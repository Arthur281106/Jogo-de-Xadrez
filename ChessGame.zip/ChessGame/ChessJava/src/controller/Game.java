package controller;

import model.board.Board;
import model.board.Position;
import model.pieces.*;

import java.util.ArrayList;
import java.util.List;

public class Game {
    private final Board board;
    private boolean whiteTurn;
    private Piece selected;
    private boolean gameOver;
    private String resultText;

    public Game() {
        board = new Board();
        board.setupInitial();
        whiteTurn = true;
        gameOver = false;
        resultText = "";
    }

    public Board getBoard() { return board; }
    public boolean isWhiteTurn() { return whiteTurn; }
    public Piece getSelectedPiece() { return selected; }
    public boolean isGameOver() { return gameOver; }
    public String getResultText() { return resultText; }

    public void select(Position p) {
        if (gameOver) return;
        Piece pc = board.getPieceAt(p);
        if (pc != null && pc.isWhite() == whiteTurn) selected = pc;
        else selected = null;
    }

    public boolean move(Position dest) {
        if (gameOver || selected == null) return false;

        List<Position> legal = legalMoves(selected);
        boolean ok = false;
        for (Position mv : legal) { if (mv.equals(dest)) { ok = true; break; } }
        if (!ok) return false;

        Position from = selected.getPosition();
        Piece captured = board.getPieceAt(dest);

        // aplicar movimento
        board.removePiece(from);
        board.placePiece(selected, dest);

        // promoção simples para rainha
        if (selected instanceof Pawn) {
            int lastRow = selected.isWhite() ? 0 : 7;
            if (selected.getPosition().getRow() == lastRow) {
                board.removePiece(selected.getPosition());
                board.placePiece(new Queen(board, selected.isWhite()),
                        new Position(lastRow, selected.getPosition().getColumn()));
            }
        }

        // verificar xeque-mate ou afogamento após trocar turno
        whiteTurn = !whiteTurn;

        if (isCheckmate(whiteTurn)) {
            gameOver = true;
            resultText = whiteTurn ? "Xeque-mate: Pretas vencem" : "Xeque-mate: Brancas vencem";
        } else if (!hasAnyLegalMove(whiteTurn) && !inCheck(whiteTurn)) {
            gameOver = true;
            resultText = "Empate por afogamento";
        }

        selected = null;
        return true;
    }

    public boolean inCheck(boolean white) {
        Position k = board.findKing(white);
        if (k == null) return false; // segurança
        return board.isUnderAttack(k, !white);
    }

    private boolean isCheckmate(boolean sideToMove) {
        return inCheck(sideToMove) && !hasAnyLegalMove(sideToMove);
    }

    private boolean hasAnyLegalMove(boolean side) {
        for (Piece p : board.getAllPieces(side)) {
            if (!legalMoves(p).isEmpty()) return true;
        }
        return false;
    }

    private List<Position> legalMoves(Piece p) {
        List<Position> res = new ArrayList<>();
        Position from = p.getPosition();
        for (Position mv : p.getMoves()) {
            Piece captured = board.getPieceAt(mv);

            // simula
            board.removePiece(from);
            board.placePiece(p, mv);
            boolean causesCheck = inCheck(p.isWhite());

            // desfaz
            board.removePiece(mv);
            board.placePiece(p, from);
            if (captured != null) board.placePiece(captured, mv);

            if (!causesCheck) res.add(mv);
        }
        return res;
    }

    // expõe para a IA/GUI
    public List<Position> getLegalMoves(Piece p) {
        if (p == null) return List.of();
        if (p.isWhite() != whiteTurn) return List.of(); // só do lado a mover
        return legalMoves(p);
    }
}
