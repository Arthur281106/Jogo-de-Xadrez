package view;

import controller.Game;
import model.board.Position;
import model.pieces.Piece;
import model.pieces.SimpleAI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ChessGUI extends JFrame {
    private final Game game;
    private final JButton[][] squares = new JButton[8][8];
    private final JLabel status = new JLabel();
    private final JComboBox<String> difficultyBox;
    private final String playerName;
    private int aiDifficulty = 0; // 0 = fácil, 1 = médio, 2 = difícil

    public ChessGUI(String playerName) {
        this.playerName = playerName;
        this.game = new Game();

        setTitle("Xadrez Java - Jogador: " + playerName);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(640, 760);
        setLayout(new BorderLayout());

        // Status do jogo
        status.setHorizontalAlignment(SwingConstants.CENTER);
        status.setFont(status.getFont().deriveFont(Font.BOLD, 16f));
        add(status, BorderLayout.NORTH);

        // Tabuleiro
        JPanel boardPanel = new JPanel(new GridLayout(8, 8));
        add(boardPanel, BorderLayout.CENTER);

        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            JButton b = new JButton();
            b.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 36));
            b.setOpaque(true);
            b.setFocusPainted(false);
            Color aqua = new Color(178, 255, 255);   // verde-água
            Color purple = new Color(200, 160, 220); // roxo clarinho (lavanda suave)
            b.setBackground(((r + c) % 2 == 0) ? aqua : purple);
            int rr = r, cc = c;
            b.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) { onClick(rr, cc); }
            });
            squares[r][c] = b;
            boardPanel.add(b);
        }

        // Controle de dificuldade da IA
        JPanel bottomPanel = new JPanel(new FlowLayout());
        difficultyBox = new JComboBox<>(new String[]{"Fácil", "Médio", "Difícil"});
        difficultyBox.addActionListener(e -> aiDifficulty = difficultyBox.getSelectedIndex());
        bottomPanel.add(new JLabel("Dificuldade da IA:"));
        bottomPanel.add(difficultyBox);
        add(bottomPanel, BorderLayout.SOUTH);

        updateBoard();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void onClick(int r, int c) {
        if (game.isGameOver()) {
            JOptionPane.showMessageDialog(this, formatResultMessage());
            return;
        }

        Position p = new Position(r, c);

        if (game.getSelectedPiece() == null) {
            game.select(p);
            highlight();
            return;
        }

        boolean moved = game.move(p);
        clearHighlights();
        updateBoard();

        if (!moved) {
            game.select(p);
            highlight();
            return;
        }

        // Verifica se o jogador venceu
        if (game.isGameOver()) {
            JOptionPane.showMessageDialog(this, formatResultMessage());
            return;
        }

        // IA joga após o jogador
        if (!game.isWhiteTurn()) {
            Timer t = new Timer(200, ev -> {
                SimpleAI ai = new SimpleAI(game, aiDifficulty);
                ai.makeMove();
                updateBoard();

                // Verifica se a IA venceu
                if (game.isGameOver()) {
                    JOptionPane.showMessageDialog(this, formatResultMessage());
                }
            });
            t.setRepeats(false);
            t.start();
        }
    }

    private String formatResultMessage() {
        String base = game.getResultText();
        return base + "\n" + playerName + ", obrigado por jogar!";
    }

    private void updateBoard() {
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            Piece pc = game.getBoard().getPieceAt(new Position(r, c));
            JButton b = squares[r][c];
            b.setText(pc == null ? "" : pc.getUnicode());
        }
        status.setText(game.isWhiteTurn() ? "Vez: Brancas" : "Vez: Pretas");
    }

    private void clearHighlights() {
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            squares[r][c].setBorder(null);
        }
    }

    private void highlight() {
        clearHighlights();
        if (game.getSelectedPiece() == null) return;
        Position pos = game.getSelectedPiece().getPosition();
        squares[pos.getRow()][pos.getColumn()].setBorder(BorderFactory.createLineBorder(Color.BLUE, 3));
    }
}
