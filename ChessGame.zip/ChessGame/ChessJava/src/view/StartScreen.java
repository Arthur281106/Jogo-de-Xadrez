package view;

import javax.swing.*;
import java.awt.*;

public class StartScreen extends JFrame {
    public StartScreen() {
        setTitle("Xadrez Java - Início");
        setSize(400, 200);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel label = new JLabel("Digite seu nome para começar:");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 16f));
        add(label, BorderLayout.NORTH);

        JTextField nameField = new JTextField();
        add(nameField, BorderLayout.CENTER);

        JButton startButton = new JButton("Começar");
        add(startButton, BorderLayout.SOUTH);

        startButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            if (!name.isEmpty()) {
                dispose(); // fecha a tela de início
                new ChessGUI(name); // abre o jogo com o nome
            } else {
                JOptionPane.showMessageDialog(this, "Digite um nome válido.");
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StartScreen::new);
    }
}
